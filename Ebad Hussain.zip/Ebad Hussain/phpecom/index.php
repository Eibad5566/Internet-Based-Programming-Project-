<?php include('includes/header.php');?>
<h4>hellow world</h4>

<buttonv class="btn btn-primary">testing</button>
<?php include('includes/footer.php');?>