








<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">

<div class="sidenav-header">
  <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
  <a class="navbar-brand m-0" href="https://www.karabuk.edu.tr/en/" target="_blank">
  
    <span class="ms-1 font-weight-bold text-white">University Of Cambridge</span>
  </a>
</div>
<div class="sub">
  <div class="subterm"></i>
    <ul>
      <li>
        <a>All features</a> <i class="material-icons opacity-10">arrow_downward
arrow_drop_down
</i>
      </li>
      <div class="subterm1">
        <ul>
          <li><a href="https://www.cam.ac.uk/">university website</a></li>
        
        </ul>
      </div>
    </ul>
  </div>
</div>
<style type="text/css">
.sub .subterm ul {
  list-style: none;
  cursor: pointer;
}
.sub .subterm ul:hover{
color: black;
box-shadow: 1px 25px 25px solid grey ;
}
  .sub .subterm ul li>a{
  font-size: 1rem;
  color: whitesmoke;
}
.sub .subterm ul .subterm1 ul {
      
    background: grey;
    height: 30px;
    width: 200px;
    transform: translateY(10px);
    transition: 0.3s;
    opacity: 0;
}.sub .subterm ul:hover .subterm1 ul {
  opacity: 1;
  color: black;
  background: grey;
}
.sub .subterm ul li .subterm1 ul li>a{
font-size: .5rem;
font-family:bold ;

}
</style>

<hr class="horizontal light mt-0 mb-2">

<div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
  <ul class="navbar-nav">
    

      

        

        

<li class="nav-item">
<a class="nav-link text-white " href="http://localhost/EBAD HUSSAIN/phpecom/admin/index.php">
  
    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
      <i class="material-icons opacity-10">dashboard</i>
    </div>
  
  <span class="nav-link-text ms-1">Dashboard</span>
</a>
</li>






<li class="nav-item">
<a class="nav-link text-white " href="http://localhost/EBAD HUSSAIN/phpecom/admin/includes/signinn/login.php ">
  
    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
      <i class="material-icons opacity-10">person</i>
    </div>
  
  <span class="nav-link-text ms-1">user login</span>
</a>
</li>


  <li class="nav-item mt-3">
    <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Account pages</h6>
  </li>

<li class="nav-item">
<a class="nav-link text-white " href="http://localhost/EBAD HUSSAIN/phpecom/signin/login.php">
  
    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
      <i class="material-icons opacity-10">person</i>
    </div>
  
  <span class="nav-link-text ms-1">Admin login</span>
</a>
</li>




<li class="nav-item">
<a class="nav-link text-white " href=" http://localhost/EBAD HUSSAIN/phpecom/crud/index.html">
  
    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
      <i class="material-icons opacity-10">group</i>
    </div>
  
  <span class="nav-link-text ms-1">Add User</span>
</a>
</li>








<li class="nav-item">
<a class="nav-link text-white " href="http://localhost/EBAD HUSSAIN/phpecom/signin/login.php">
  
    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
      <i class="material-icons opacity-10">login</i>
    </div>
  
  <span class="nav-link-text ms-1">Sign In</span>
</a>
</li>





<div class="sidenav-footer position-absolute w-100 bottom-0 ">
  <div class="mx-3">
    <a class="btn bg-gradient-primary mt-4 w-100" href="http://localhost/EBAD HUSSAIN/phpecom/test/index.html" type="button">sign up</a>
  </div>
  
</div>
<style>

 
</style>
</aside>

