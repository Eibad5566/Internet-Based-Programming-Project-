

<footer class="footer pt-5">
      <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
          <div class="col-lg-12 ">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">
              
              <li class="nav-item">
                <a href="https://www.cam.ac.uk/about-the-university" class="nav-link text-muted" target="_blank">About</a>
              </li>
                <li class="nav-item">
                <a href="https://www.cam.ac.uk/about-the-university/contact-the-university" class="nav-link pe-0 text-muted" target="_blank">contact</a>
                <li class="nav-item">
                <a href="https://en.wikipedia.org/wiki/University_of_Cambridge" class="nav-link pe-0 text-muted" target="_blank">details</a>
              </li> <li class="nav-item">
            </ul>
          </div>
        </div>
      </div>
    </footer>
</main>
<script src="../assets/js/bootsrap.bundle.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
<script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>

</body>
</html>