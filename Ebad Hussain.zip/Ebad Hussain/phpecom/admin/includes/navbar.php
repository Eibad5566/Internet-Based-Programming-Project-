<form action="http://www.google.com" method="get">
  <div class="btnn">
<input action="http://www.google.com" method="get"  name="q" placeholder="write here">
<button class="submit" >search here</button>

</div>
</form>


<style>
  
.btnn{
  align-content: center;
  margin-left: 700px;
  padding: 4px;
  
}



</style>