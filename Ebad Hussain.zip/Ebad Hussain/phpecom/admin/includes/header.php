<!DOCTYPE html>
<html lang="en">
  <head>


<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



<title>
  
University Of Cambridge  
</title>

    <header class="header">
    <a href="#"  class="logo">
        <img src="images/13.jpg"  alt="">
</a>



<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />



<script src="kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">





<link id="pagestyle" href="assets/css/material-dashboard.min.css" rel="stylesheet" />
</head>
<body class="g-sidenav-slow   bg-grey-200">
  
    <?php include('sidebar.php');?>
<main class="main-content position-relative max-height-vh-100 h-200 border-radius-lg ">
<?php include('navbar.php');?>

