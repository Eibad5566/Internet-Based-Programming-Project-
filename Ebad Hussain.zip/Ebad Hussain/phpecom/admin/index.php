<?php include('includes/header.php');?>




<div class="container">
<div class="row">
    <div class="col-md-12">
        <h1>   UNIVERSITY OF CAMBRIDGE  </h1>

<div class="slideshow">
  <img src="Uni 1.jpg" alt="Image 1">
  <img src="Uni 2.jpg" alt="Image 2">
  <img src="Uni 3.jpg" alt="Image 3">
 
</div>

<style type="text/css">.slideshow {
  white-space: nowrap;
  overflow: hidden; 
  animation: slide 10s linear infinite; 
}

.slideshow img {
  display: inline-block;
  height: 420px;
}

@keyframes slide {
  0% {
    transform: translateX(14); 
  }
  100% {
    transform: translateX(100%); 
  }
}
</style>


</div>
    </div>
</div>


<style type="text/css">
    h1{
        margin-left: 240px;
    }
</style>
  



<?php include('includes/footer.php');?>